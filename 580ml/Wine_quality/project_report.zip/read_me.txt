to run our program and check the outcome during processing:

$python3 rough_test.py -> 
the rough accuracy for the multi-classification problem with labels ranging from 0~10

$python3 wine_prediction.py -> 
1.the pie charts before and after the transformation into a tenary classification problem which shows the distribution over different labels,showing the imbalance of the dataset.
2. one hotmap showing the correlation among these features.
3. after feature selection and hyperparater tuning, the best combination of hyperparameters groupsa and the accuracy of our final model

